#pragma once
#define WIN32_LEAN_AND_MEAN

#include "targetver.h"
#include <windows.h>
#include <detours.h>
#include <d3d11.h>
#include <d3dcompiler.h>
#include <iostream>
